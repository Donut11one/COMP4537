// This file stores all user-facing strings to be used in script.js.
// Using this file helps with maintaining code and future localization.

const messages = {
    storedAt: "stored at:",
    updatedAt: "updated at:",
    removeButtonText: "remove",
    addButtonText: "add"
};